<?php
/**
 * Banner post type and editor fields.
 *
 * @package Beastside3DHeroBanner
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BS3D_Banner_Post_Type {
	/**
	 * Register hooks.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_post_type' ) );
		add_action( 'add_meta_boxes', array( __CLASS__, 'register_meta_boxes' ) );
		add_action( 'save_post_bs3d_banner', array( __CLASS__, 'save_meta' ) );
	}

	/**
	 * Register banner post type.
	 */
	public static function register_post_type() {
		$labels = array(
			'name'          => __( '3D Banners', 'beastside-3d-hero-banner' ),
			'singular_name' => __( '3D Banner', 'beastside-3d-hero-banner' ),
			'menu_name'     => __( '3D Banners', 'beastside-3d-hero-banner' ),
		);

		register_post_type(
			'bs3d_banner',
			array(
				'labels'          => $labels,
				'public'          => false,
				'show_ui'         => true,
				'show_in_menu'    => false,
				'supports'        => array( 'title' ),
				'capability_type' => 'post',
				'map_meta_cap'    => true,
				'rewrite'         => false,
			)
		);
	}

	/**
	 * Register banner meta box fields.
	 */
	public static function register_meta_boxes() {
		add_meta_box(
			'bs3d_banner_config',
			__( 'Banner Configuration', 'beastside-3d-hero-banner' ),
			array( __CLASS__, 'render_config_meta_box' ),
			'bs3d_banner',
			'normal',
			'high'
		);
	}

	/**
	 * Render banner config box.
	 *
	 * @param WP_Post $post Current post.
	 */
	public static function render_config_meta_box( WP_Post $post ) {
		wp_nonce_field( 'bs3d_banner_save_meta', 'bs3d_banner_meta_nonce' );

		$scene_config   = get_post_meta( $post->ID, '_bs3d_scene_config', true );
		$debug_override = get_post_meta( $post->ID, '_bs3d_debug_override', true );
		$poster_url     = get_post_meta( $post->ID, '_bs3d_poster_url', true );
		$quality        = get_post_meta( $post->ID, '_bs3d_quality_profile', true );
		$mobile_mode    = get_post_meta( $post->ID, '_bs3d_mobile_mode', true );

		if ( empty( $scene_config ) ) {
			$scene_config = wp_json_encode(
				array(
					'models'      => array(),
					'background'  => array( 'mode' => 'static' ),
					'interactions'=> array(
						'tilt'     => true,
						'rotate'   => true,
						'parallax' => true,
					),
				),
				JSON_PRETTY_PRINT
			);
		}

		if ( empty( $debug_override ) ) {
			$debug_override = 'inherit';
		}

		if ( empty( $quality ) ) {
			$quality = 'balanced';
		}

		if ( empty( $mobile_mode ) ) {
			$mobile_mode = 'adaptive';
		}
		?>
		<p>
			<label for="bs3d_poster_url"><strong><?php esc_html_e( 'Poster Fallback URL', 'beastside-3d-hero-banner' ); ?></strong></label><br />
			<input type="url" id="bs3d_poster_url" name="bs3d_poster_url" value="<?php echo esc_attr( $poster_url ); ?>" class="widefat" placeholder="https://example.com/poster.jpg" />
		</p>
		<p>
			<label for="bs3d_debug_override"><strong><?php esc_html_e( 'Debug Override', 'beastside-3d-hero-banner' ); ?></strong></label><br />
			<select id="bs3d_debug_override" name="bs3d_debug_override">
				<option value="inherit" <?php selected( 'inherit', $debug_override ); ?>><?php esc_html_e( 'Inherit Global', 'beastside-3d-hero-banner' ); ?></option>
				<option value="on" <?php selected( 'on', $debug_override ); ?>><?php esc_html_e( 'Force On', 'beastside-3d-hero-banner' ); ?></option>
				<option value="off" <?php selected( 'off', $debug_override ); ?>><?php esc_html_e( 'Force Off', 'beastside-3d-hero-banner' ); ?></option>
			</select>
		</p>
		<p>
			<label for="bs3d_quality_profile"><strong><?php esc_html_e( 'Quality Profile', 'beastside-3d-hero-banner' ); ?></strong></label><br />
			<select id="bs3d_quality_profile" name="bs3d_quality_profile">
				<option value="balanced" <?php selected( 'balanced', $quality ); ?>><?php esc_html_e( 'Balanced', 'beastside-3d-hero-banner' ); ?></option>
				<option value="visual" <?php selected( 'visual', $quality ); ?>><?php esc_html_e( 'Visual First', 'beastside-3d-hero-banner' ); ?></option>
				<option value="performance" <?php selected( 'performance', $quality ); ?>><?php esc_html_e( 'Performance First', 'beastside-3d-hero-banner' ); ?></option>
			</select>
		</p>
		<p>
			<label for="bs3d_mobile_mode"><strong><?php esc_html_e( 'Mobile Interaction Mode', 'beastside-3d-hero-banner' ); ?></strong></label><br />
			<select id="bs3d_mobile_mode" name="bs3d_mobile_mode">
				<option value="adaptive" <?php selected( 'adaptive', $mobile_mode ); ?>><?php esc_html_e( 'Adaptive', 'beastside-3d-hero-banner' ); ?></option>
				<option value="full" <?php selected( 'full', $mobile_mode ); ?>><?php esc_html_e( 'Full', 'beastside-3d-hero-banner' ); ?></option>
				<option value="reduced" <?php selected( 'reduced', $mobile_mode ); ?>><?php esc_html_e( 'Reduced', 'beastside-3d-hero-banner' ); ?></option>
				<option value="off" <?php selected( 'off', $mobile_mode ); ?>><?php esc_html_e( 'Off', 'beastside-3d-hero-banner' ); ?></option>
			</select>
		</p>
		<p>
			<label for="bs3d_scene_config"><strong><?php esc_html_e( 'Scene Config (JSON)', 'beastside-3d-hero-banner' ); ?></strong></label>
			<textarea id="bs3d_scene_config" name="bs3d_scene_config" rows="14" class="widefat code"><?php echo esc_textarea( $scene_config ); ?></textarea>
		</p>
		<?php
	}

	/**
	 * Save banner metadata.
	 *
	 * @param int $post_id Post ID.
	 */
	public static function save_meta( $post_id ) {
		if ( ! isset( $_POST['bs3d_banner_meta_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['bs3d_banner_meta_nonce'] ) ), 'bs3d_banner_save_meta' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		$scene_config = isset( $_POST['bs3d_scene_config'] ) ? wp_unslash( $_POST['bs3d_scene_config'] ) : '';
		$decoded      = json_decode( (string) $scene_config, true );
		if ( is_array( $decoded ) ) {
			update_post_meta( $post_id, '_bs3d_scene_config', wp_json_encode( $decoded ) );
		}

		$override = isset( $_POST['bs3d_debug_override'] ) ? sanitize_key( wp_unslash( $_POST['bs3d_debug_override'] ) ) : 'inherit';
		if ( ! in_array( $override, array( 'inherit', 'on', 'off' ), true ) ) {
			$override = 'inherit';
		}
		update_post_meta( $post_id, '_bs3d_debug_override', $override );

		$poster = isset( $_POST['bs3d_poster_url'] ) ? esc_url_raw( wp_unslash( $_POST['bs3d_poster_url'] ) ) : '';
		update_post_meta( $post_id, '_bs3d_poster_url', $poster );

		$quality = isset( $_POST['bs3d_quality_profile'] ) ? sanitize_key( wp_unslash( $_POST['bs3d_quality_profile'] ) ) : 'balanced';
		if ( ! in_array( $quality, array( 'balanced', 'visual', 'performance' ), true ) ) {
			$quality = 'balanced';
		}
		update_post_meta( $post_id, '_bs3d_quality_profile', $quality );

		$mobile_mode = isset( $_POST['bs3d_mobile_mode'] ) ? sanitize_key( wp_unslash( $_POST['bs3d_mobile_mode'] ) ) : 'adaptive';
		if ( ! in_array( $mobile_mode, array( 'adaptive', 'full', 'reduced', 'off' ), true ) ) {
			$mobile_mode = 'adaptive';
		}
		update_post_meta( $post_id, '_bs3d_mobile_mode', $mobile_mode );
	}

	/**
	 * Fetch stored banner config.
	 *
	 * @param int $post_id Banner post ID.
	 * @return array<string,mixed>
	 */
	public static function get_banner_data( $post_id ) {
		$post = get_post( $post_id );
		if ( ! $post || 'bs3d_banner' !== $post->post_type ) {
			return array();
		}

		$scene_json = get_post_meta( $post_id, '_bs3d_scene_config', true );
		$scene      = json_decode( (string) $scene_json, true );
		if ( ! is_array( $scene ) ) {
			$scene = array();
		}

		return array(
			'id'            => (int) $post_id,
			'title'         => $post->post_title,
			'slug'          => $post->post_name,
			'scene'         => $scene,
			'debug_override'=> (string) get_post_meta( $post_id, '_bs3d_debug_override', true ) ?: 'inherit',
			'poster_url'    => (string) get_post_meta( $post_id, '_bs3d_poster_url', true ),
			'quality'       => (string) get_post_meta( $post_id, '_bs3d_quality_profile', true ) ?: 'balanced',
			'mobile_mode'   => (string) get_post_meta( $post_id, '_bs3d_mobile_mode', true ) ?: 'adaptive',
		);
	}
}
