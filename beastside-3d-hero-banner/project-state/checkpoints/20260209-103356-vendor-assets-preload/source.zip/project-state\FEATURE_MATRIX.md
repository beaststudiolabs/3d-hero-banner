﻿# Feature Matrix

This matrix tracks all agreed features from the full chat context, ties them to implementation files, and records checkpoint lineage.

| feature_id | source_decision | status | owner | files | tests | checkpoint_id |
|---|---|---|---|---|---|---|
| BS3D-F001 | Plugin objective is whitelist/signup conversion via hero banner. | implemented | codex | beastside-3d-hero-banner/README.md | Manual product review | 20260209-101640-baseline-full-chat |
| BS3D-F002 | Launch surfaces are Elementor widget + shortcode. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-elementor-widget.php; beastside-3d-hero-banner/includes/class-bs3d-renderer.php | Render in Elementor and shortcode pages | 20260209-101640-baseline-full-chat |
| BS3D-F003 | 3D layer only; CTA/content owned outside plugin. | implemented | codex | beastside-3d-hero-banner/README.md | Content ownership review | 20260209-101640-baseline-full-chat |
| BS3D-F004 | Banner data model supports per-banner controls including debug override and runtime profile/mode. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-banner-post-type.php | Save/edit banner meta flow | 20260209-101640-baseline-full-chat |
| BS3D-F005 | Global debug settings exist and default ON. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-settings.php | Settings defaults and save behavior | 20260209-101640-baseline-full-chat |
| BS3D-F006 | Debug verbosity supports errors/normal/verbose. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-settings.php; beastside-3d-hero-banner/assets/js/frontend.js | Overlay/log output by mode | 20260209-101640-baseline-full-chat |
| BS3D-F007 | Overlay toggle exists globally and defaults ON. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-settings.php; beastside-3d-hero-banner/includes/class-bs3d-renderer.php | Toggle disables overlay injection | 20260209-101640-baseline-full-chat |
| BS3D-F008 | Per-banner debug override resolves against global setting. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-settings.php; beastside-3d-hero-banner/includes/class-bs3d-banner-post-type.php; beastside-3d-hero-banner/includes/class-bs3d-renderer.php | Override precedence checks | 20260209-101640-baseline-full-chat |
| BS3D-F009 | Diagnostics persisted in custom DB table. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-diagnostics.php | DB table create/insert/query | 20260209-101640-baseline-full-chat |
| BS3D-F010 | Daily retention cleanup at 14 days. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-diagnostics.php; beastside-3d-hero-banner/includes/class-bs3d-settings.php; beastside-3d-hero-banner/includes/class-bs3d-plugin.php | Simulated old-row cleanup | 20260209-101640-baseline-full-chat |
| BS3D-F011 | Diagnostics admin page with setup status cards. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-plugin.php; beastside-3d-hero-banner/includes/class-bs3d-diagnostics.php; beastside-3d-hero-banner/assets/css/admin.css | Admin UI status card check | 20260209-101640-baseline-full-chat |
| BS3D-F012 | Log stream supports level/context/banner/slug filters. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-plugin.php; beastside-3d-hero-banner/includes/class-bs3d-diagnostics.php | Filtered query correctness | 20260209-101640-baseline-full-chat |
| BS3D-F013 | Export diagnostics JSON action. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-plugin.php | Export payload schema check | 20260209-101640-baseline-full-chat |
| BS3D-F014 | Clear diagnostics logs action. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-plugin.php; beastside-3d-hero-banner/includes/class-bs3d-diagnostics.php | Clear action + empty table check | 20260209-101640-baseline-full-chat |
| BS3D-F015 | Frontend debug overlay top-left with green text. | implemented | codex | beastside-3d-hero-banner/assets/js/frontend.js; beastside-3d-hero-banner/assets/css/frontend.css | Visual and field render check | 20260209-101640-baseline-full-chat |
| BS3D-F016 | Overlay restricted to logged-in admins only. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-renderer.php; beastside-3d-hero-banner/assets/js/frontend.js | Anonymous user overlay absence | 20260209-101640-baseline-full-chat |
| BS3D-F017 | Fallback poster behavior for runtime failures. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-renderer.php; beastside-3d-hero-banner/assets/js/frontend.js; beastside-3d-hero-banner/assets/css/frontend.css | Trigger failure path and verify poster | 20260209-101640-baseline-full-chat |
| BS3D-F018 | Debug/event dispatch includes required debug events. | implemented | codex | beastside-3d-hero-banner/assets/js/frontend.js | Window event listener assertions | 20260209-101640-baseline-full-chat |
| BS3D-F019 | Startup critical checks log warnings when setup gaps exist. | implemented | codex | beastside-3d-hero-banner/includes/class-bs3d-plugin.php; beastside-3d-hero-banner/includes/class-bs3d-diagnostics.php | Startup warning record creation | 20260209-101640-baseline-full-chat |
| BS3D-F020 | Save-state and context documentation system is mandatory for each accepted change. | validated | codex | beastside-3d-hero-banner/project-state/* | Checkpoint artifact and docs consistency checks | 20260209-101640-baseline-full-chat |
| BS3D-F021 | Vendor runtime assets must be preloaded in plugin package for one-shot install (Three.js, GLTFLoader, Draco, Meshopt). | validated | codex | beastside-3d-hero-banner/assets/vendor/*; beastside-3d-hero-banner/README.md; beastside-3d-hero-banner/assets/vendor/VENDOR_SOURCES.md | Vendor file presence and diagnostics setup card readiness | 20260209-103356-vendor-assets-preload |




