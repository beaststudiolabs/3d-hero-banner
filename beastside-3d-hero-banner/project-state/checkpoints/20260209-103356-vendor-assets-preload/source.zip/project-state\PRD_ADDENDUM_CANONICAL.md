﻿# Beastside 3D Hero Banner: Canonical PRD Addendum

## Purpose
This document is the canonical source of approved requirements and acceptance criteria for the current build stream. It captures decisions made across this chat timeline and is paired with `BUILD_LOG.md`, `FEATURE_MATRIX.md`, and checkpoint manifests.

## Product Goal
- Primary goal: use a high-impact 3D hero banner to increase whitelist/signup conversion intent for the multiplayer game website.
- Plugin scope: 3D visual layer only.
- Hero copy and CTA controls are owned by Elementor/theme content systems.

## Launch Scope (Current)
- Embedding surfaces:
- Elementor widget.
- Shortcode API.
- Runtime model strategy:
- GLB/GLTF runtime with conversion workflow from FBX.
- Diagnostics/debug:
- Global debug controls with default ON.
- Per-banner override support (`inherit|on|off`).
- Backend diagnostics panel and log pipeline.
- Frontend admin-only debug overlay (top-left green text).

## Canonical Requirements

### Global Debug Controls
- `bs3d_debug_enabled` default `true`.
- `bs3d_debug_verbosity` values: `errors|normal|verbose`, default `normal`.
- `bs3d_debug_overlay_enabled` default `true`.
- `bs3d_debug_retention_days` fixed to `14` in v1 UI (read-only).
- Manual clear logs action is available to admins.

### Per-Banner Debug Override
- Banner metadata includes `debugOverride`:
- `inherit` (default).
- `on`.
- `off`.
- Effective resolution:
- `on` forces enabled.
- `off` forces disabled.
- Otherwise inherit global toggle.

### Diagnostics Panel
- Admin-only diagnostics page contains:
- Status cards:
- Three.js runtime availability.
- GLTF loader availability.
- Draco decoder configuration.
- Meshopt decoder configuration.
- Elementor widget registration.
- Shortcode registration.
- Last successful render timestamp.
- Last error timestamp.
- Log stream with filters:
- Level: `info|warn|error`.
- Context/surface: `admin-preview|frontend|elementor|shortcode|import-export|startup`.
- Banner ID.
- Slug.
- Export JSON action for filtered results.
- Clear logs action.

### Frontend Debug Overlay
- Rendered inside each banner container.
- Position: top-left.
- Style: green monospace text with readable dark translucent backing.
- Visibility: logged-in admins only.
- Normal mode shows:
- Banner ID/slug.
- Surface mode.
- Device mode.
- Effective quality profile.
- Model load counts.
- Fallback status and reason.
- Last warning/error summary.
- Verbose mode additionally shows:
- Load duration.
- FPS bucket.
- Draw call estimate.

### Events and Diagnostics Shape
- Frontend emits debug events:
- `bs3d.debug_status`
- `bs3d.debug_warning`
- `bs3d.debug_error`
- `bs3d.debug_overlay_rendered`
- Runtime/behavioral events emitted:
- `bs3d.banner_loaded`
- `bs3d.banner_visible`
- `bs3d.interaction_start`
- `bs3d.interaction_end`
- `bs3d.fallback_shown`
- `bs3d.load_error`
- Diagnostics record shape:
- `timestamp`
- `level`
- `bannerId`
- `slug`
- `surface`
- `code`
- `message`
- `meta`

### Retention and Safety
- Diagnostics are persisted in plugin-managed DB table.
- Cleanup runs daily.
- Retention policy: keep last 14 days, delete older records.
- Do not store PII/secrets in persisted metadata.
- URLs and error payloads are sanitized before storage/display/export.

### Vendor Asset Packaging
- Vendor runtime assets must be bundled in plugin package so installation is one shot.
- Required bundled runtime files:
- `assets/vendor/three/three.min.js`
- `assets/vendor/three/GLTFLoader.js`
- `assets/vendor/draco/draco_decoder.js`
- `assets/vendor/draco/draco_wasm_wrapper.js`
- `assets/vendor/draco/draco_decoder.wasm`
- `assets/vendor/meshopt/meshopt_decoder.js`
- License/source metadata must be documented in `assets/vendor/VENDOR_SOURCES.md`.
- Diagnostics setup cards should resolve runtime/decoder availability from these bundled assets after plugin install.

## Acceptance Criteria
1. New install has global debug enabled by default.
2. Admin can disable debug globally; non-critical logging/overlay respects disabled state.
3. Per-banner override supersedes global state as designed.
4. Overlay is visible to logged-in admins only and never public visitors.
5. Overlay appears top-left in green text and shows expected status fields.
6. Diagnostics panel shows setup status and filtered logs.
7. Known runtime issues (missing loader/runtime, timeout/fallback paths) generate diagnostic records.
8. 14-day retention cleanup runs and removes older records.
9. Elementor and shortcode rendering paths continue to work with debug both on/off.
10. Normal debug mode introduces minimal runtime overhead.

## Non-Negotiable Defaults
- Debug mode defaults ON.
- Overlay defaults ON but admin-only.
- Retention fixed at 14 days in v1.
- Checkpoint and docs updates are mandatory for every accepted change.

## Save-State Standard
- Root folder: `beastside-3d-hero-banner/project-state`.
- Checkpoint folder naming: `beastside-3d-hero-banner/project-state/checkpoints/YYYYMMDD-HHMMSS-change-slug`.
- Required files inside each checkpoint folder:
- `source.zip`
- `manifest.json`
- `diff-summary.md`
- `restore.md`
- Checkpoint trigger: every accepted change that modifies code, configuration, or documentation in build scope.
- Rollback default: latest stable checkpoint in `CHECKPOINT_INDEX.md`, unless a specific checkpoint ID is requested.

## Interface Standards
- `manifest.json` required fields:
- `checkpoint_id`
- `created_utc`
- `change_slug`
- `scope`
- `summary`
- `files_snapshot_root`
- `artifact_sha256`
- `feature_ids`
- `validation` with `syntax`, `manual_checks`, `known_gaps`
- `BUILD_LOG.md` required entry fields:
- `checkpoint_id`
- `date_utc`
- `request`
- `decision`
- `files`
- `risks`
- `validation`
- `next_actions`
- `FEATURE_MATRIX.md` ID format:
- `BS3D-F###`
- IDs are immutable after creation.

## Workflow Rules
1. Read latest `PRD_ADDENDUM_CANONICAL.md`, `BUILD_LOG.md`, `FEATURE_MATRIX.md`, and latest checkpoint `manifest.json`.
2. Implement accepted change.
3. Update all three core docs.
4. Create checkpoint folder with required files.
5. Append or update `CHECKPOINT_INDEX.md`.
6. Run validation checklist and record outcomes in `BUILD_LOG.md`.
7. Mark relevant feature rows as `validated` only after checks pass.

## Validation Scenarios
1. Save-state integrity:
- Check required checkpoint files exist.
- Verify `artifact_sha256` matches `source.zip`.
- Confirm restore instructions are complete and executable.
2. Documentation consistency:
- Ensure each checkpoint has corresponding entries in `BUILD_LOG.md` and `CHECKPOINT_INDEX.md`.
- Ensure each implemented feature row maps to at least one checkpoint ID.
3. Traceability:
- Select any feature row and confirm linked files and evidence match checkpoint artifacts.
4. Rollback drill:
- Restore from latest stable checkpoint and verify expected structure and docs.
5. Context continuity:
- Verify a new contributor can determine current state and next action from the 3-doc set.

## Change History
| checkpoint_id | date_utc | summary |
|---|---|---|
| 20260209-101640-baseline-full-chat | 2026-02-09T10:16:40Z | Initial canonical backfill from full chat scope (core + diagnostics). |
| 20260209-103356-vendor-assets-preload | 2026-02-09T10:33:56Z | Vendored Three.js/GLTFLoader/Draco/Meshopt assets for one-shot plugin installation and updated source/license documentation. |




