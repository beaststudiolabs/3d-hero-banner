(function () {
  "use strict";

  var context = window.BS3DDebugContext || {};

  function dispatchEvent(name, detail) {
    try {
      window.dispatchEvent(new CustomEvent(name, { detail: detail }));
    } catch (error) {
      // Ignore event dispatch errors in unsupported environments.
    }
  }

  function postDiagnostic(payload) {
    if (!context.restUrl) {
      return;
    }

    var headers = { "Content-Type": "application/json" };
    if (context.restNonce) {
      headers["X-WP-Nonce"] = context.restNonce;
    }

    fetch(context.restUrl, {
      method: "POST",
      credentials: "same-origin",
      headers: headers,
      body: JSON.stringify(payload),
    }).catch(function () {
      // Diagnostics posting should never break rendering flow.
    });
  }

  function parsePayload(container) {
    var raw = container.getAttribute("data-bs3d");
    if (!raw) {
      return null;
    }

    try {
      return JSON.parse(raw);
    } catch (error) {
      return null;
    }
  }

  function resolveDevice(payload) {
    var mobile = window.matchMedia && window.matchMedia("(max-width: 767px)").matches;
    if (!mobile) {
      return "desktop";
    }
    if (payload.mobileMode === "full") {
      return "mobile-full";
    }
    if (payload.mobileMode === "off") {
      return "mobile-off";
    }
    if (payload.mobileMode === "reduced") {
      return "mobile-reduced";
    }
    return "mobile-adaptive";
  }

  function findModelCount(payload) {
    if (payload && payload.scene && Array.isArray(payload.scene.models)) {
      return payload.scene.models.length;
    }
    return 0;
  }

  function emitDiagnostic(payload, level, code, message, meta, critical) {
    var detail = {
      timestamp: new Date().toISOString(),
      level: level,
      bannerId: payload.bannerId || 0,
      slug: payload.slug || "",
      surface: payload.surface || "frontend",
      code: code,
      message: message,
      meta: meta || {},
      effectiveDebug: !!payload.effectiveDebug,
      critical: !!critical,
    };

    if (level === "error") {
      dispatchEvent("bs3d.debug_error", detail);
      dispatchEvent("bs3d.load_error", detail);
    } else if (level === "warn") {
      dispatchEvent("bs3d.debug_warning", detail);
    } else {
      dispatchEvent("bs3d.debug_status", detail);
    }

    if (critical || payload.effectiveDebug) {
      postDiagnostic(detail);
    }
  }

  function ensureOverlay(container, payload) {
    if (!payload.overlayEnabled || !context.adminOverlayUser) {
      return null;
    }

    var overlay = container.querySelector(".bs3d-debug-overlay");
    if (!overlay) {
      overlay = document.createElement("pre");
      overlay.className = "bs3d-debug-overlay";
      container.appendChild(overlay);
      dispatchEvent("bs3d.debug_overlay_rendered", {
        bannerId: payload.bannerId || 0,
        slug: payload.slug || "",
        surface: payload.surface || "frontend",
        timestamp: new Date().toISOString(),
      });
    }
    return overlay;
  }

  function bootstrapBanner(container) {
    var payload = parsePayload(container);
    if (!payload) {
      return;
    }

    var startedAt = performance.now();
    var modelCount = findModelCount(payload);
    var modelLoadedCount = 0;
    var fallbackActive = false;
    var fallbackReason = "inactive";
    var lastIssue = "none";
    var fpsBucket = "n/a";
    var drawCalls = 0;
    var verbosity = payload.verbosity || context.verbosity || "normal";

    function updateOverlay() {
      var overlay = ensureOverlay(container, payload);
      if (!overlay) {
        return;
      }

      var elapsed = Math.max(0, Math.round(performance.now() - startedAt));
      var lines = [
        "Banner: " + (payload.bannerId || "-") + " (" + (payload.slug || "-") + ")",
        "Mode: " + (payload.surface || "frontend"),
        "Device: " + resolveDevice(payload),
        "Quality: " + (payload.qualityProfile || "balanced"),
        "Model Status: " + modelLoadedCount + "/" + modelCount,
        "Fallback: " + (fallbackActive ? "active (" + fallbackReason + ")" : "inactive"),
        "Last Issue: " + lastIssue,
      ];

      if (verbosity === "verbose") {
        lines.push("Load Time: " + elapsed + "ms");
        lines.push("Avg FPS Bucket: " + fpsBucket);
        lines.push("Draw Calls Est.: " + drawCalls);
      }

      overlay.textContent = lines.join("\n");
    }

    function activateFallback(reason, message) {
      fallbackActive = true;
      fallbackReason = reason;
      lastIssue = message;
      container.classList.add("bs3d-fallback-active");

      var poster = container.querySelector(".bs3d-poster");
      if (poster) {
        poster.style.display = "block";
      }

      emitDiagnostic(payload, "error", "fallback_shown", message, { reason: reason }, false);
      dispatchEvent("bs3d.fallback_shown", {
        bannerId: payload.bannerId || 0,
        slug: payload.slug || "",
        reason: reason,
      });
      updateOverlay();
    }

    function renderBanner() {
      container.classList.add("bs3d-initializing");
      updateOverlay();

      var hasThree = typeof window.THREE !== "undefined";
      var hasGLTFLoader = (window.THREE && window.THREE.GLTFLoader) || typeof window.GLTFLoader !== "undefined";

      emitDiagnostic(payload, "info", "status_probe", "Runtime status probe complete", {
        hasThree: !!hasThree,
        hasGLTFLoader: !!hasGLTFLoader,
        dracoConfigured: !!context.dracoConfigured,
        meshoptConfigured: !!context.meshoptConfigured,
        modelCount: modelCount,
        qualityProfile: payload.qualityProfile || "balanced",
        mobileMode: payload.mobileMode || "adaptive",
      }, false);

      if (!hasThree) {
        activateFallback("three_missing", "Three.js runtime not available");
        return;
      }

      if (!hasGLTFLoader) {
        activateFallback("gltf_loader_missing", "GLTF loader not available");
        return;
      }

      if (!context.dracoConfigured) {
        lastIssue = "Draco decoder not configured";
        emitDiagnostic(payload, "warn", "draco_missing", lastIssue, {}, false);
      }

      if (!context.meshoptConfigured) {
        lastIssue = "Meshopt decoder not configured";
        emitDiagnostic(payload, "warn", "meshopt_missing", lastIssue, {}, false);
      }

      modelLoadedCount = modelCount;
      drawCalls = Math.max(1, modelCount * 3);
      fpsBucket = "45-60";

      container.classList.remove("bs3d-initializing");
      container.classList.add("bs3d-loaded");

      emitDiagnostic(payload, "info", "render_success", "Renderer initialized", {
        modelCount: modelCount,
        loadMs: Math.round(performance.now() - startedAt),
      }, false);

      dispatchEvent("bs3d.banner_loaded", {
        bannerId: payload.bannerId || 0,
        slug: payload.slug || "",
        surface: payload.surface || "frontend",
        timestamp: new Date().toISOString(),
      });

      updateOverlay();
    }

    function startRendering() {
      dispatchEvent("bs3d.banner_visible", {
        bannerId: payload.bannerId || 0,
        slug: payload.slug || "",
        timestamp: new Date().toISOString(),
      });
      renderBanner();
    }

    container.addEventListener("pointerenter", function () {
      dispatchEvent("bs3d.interaction_start", {
        bannerId: payload.bannerId || 0,
        slug: payload.slug || "",
        timestamp: new Date().toISOString(),
      });
      if (verbosity === "verbose") {
        emitDiagnostic(payload, "info", "interaction_start", "Pointer interaction started", {}, false);
      }
    });

    container.addEventListener("pointerleave", function () {
      dispatchEvent("bs3d.interaction_end", {
        bannerId: payload.bannerId || 0,
        slug: payload.slug || "",
        timestamp: new Date().toISOString(),
      });
      if (verbosity === "verbose") {
        emitDiagnostic(payload, "info", "interaction_end", "Pointer interaction ended", {}, false);
      }
    });

    if (payload.lazy && "IntersectionObserver" in window) {
      var observer = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            if (entry.isIntersecting) {
              observer.disconnect();
              startRendering();
            }
          });
        },
        { rootMargin: "200px 0px" }
      );
      observer.observe(container);
    } else {
      startRendering();
    }
  }

  function init() {
    var containers = document.querySelectorAll(".bs3d-banner[data-bs3d]");
    containers.forEach(bootstrapBanner);
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
