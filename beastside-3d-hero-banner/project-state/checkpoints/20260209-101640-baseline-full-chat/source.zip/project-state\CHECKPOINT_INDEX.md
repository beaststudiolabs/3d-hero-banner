﻿# Checkpoint Index

Latest stable checkpoint should be used for rollback unless a specific checkpoint ID is requested.

| checkpoint_id | date_utc | change_slug | scope | summary | stable |
|---|---|---|---|---|---|
| 20260209-101640-baseline-full-chat | 2026-02-09T10:16:40Z | baseline-full-chat | full-chat-backfill | Initial context preservation baseline with full-chat feature/documentation backfill. | yes |

## Rollback Rule
- Default rollback target: latest row with `stable = yes`.
- If a specific checkpoint is requested, use that checkpoint ID exactly.



